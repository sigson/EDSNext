package org.primftpd.util;

public enum TmpDirType {
    QUICK_SHARE,
    ROOT_COPY
}
