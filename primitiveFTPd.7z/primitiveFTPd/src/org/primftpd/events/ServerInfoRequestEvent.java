package org.primftpd.events;

/**
 * Eventbus event to query information from running server.
 */
public class ServerInfoRequestEvent {
}
