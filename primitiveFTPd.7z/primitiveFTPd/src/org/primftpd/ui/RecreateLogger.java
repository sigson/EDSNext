package org.primftpd.ui;

public interface RecreateLogger {
    void recreateLogger();
}
